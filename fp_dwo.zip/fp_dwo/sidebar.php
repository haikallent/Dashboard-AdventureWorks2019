 <!-- Sidebar -->
 <ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion" id="accordionSidebar">

     <!-- Sidebar - Brand -->
     <a class="sidebar-brand d-flex align-items-center justify-content-center" href="home.php">
         <div class="sidebar-brand-icon rotate-n-15">
         <i class="fas fa-bicycle"></i>
         </div>
         <div class="sidebar-brand-text mx-3">ADVENTURE WORK</div>
     </a>

     <!-- Divider -->
     <hr class="sidebar-divider">

     <!-- Heading User Profile-->
     <div class="sidebar-heading">
         Grafik Data ADVENTURE WORK
     </div>

     <!-- Nav Item - My Profile -->
     <li class="nav-item">
         <a class="nav-link" href="linechart.php">
         <i class="fas fa-dollar-sign"></i>
             <span>Data Sales per Kategori</span></a>
     </li>

     <li class="nav-item">
         <a class="nav-link" href="linechart2.php">
         <i class="fas fa-dollar-sign"></i>
             <span>Data purchase per Kategori</span></a>
     </li>

     <!-- Nav Item - Edit Profile -->
     <li class="nav-item">
         <a class="nav-link" href="barchart.php">
         <i class="fas fa-money-bill"></i>
             <span>Cabang Teratas(Sales)</span></a>
     </li>

     <!-- Nav Item - Edit Profile -->
     <li class="nav-item">
         <a class="nav-link" href="barchart2.php">
         <i class="fas fa-money-bill"></i>
             <span>Vendor Teratas (Purchase)</span></a>
     </li>

               <!-- Nav Item - Edit Profile -->
    <li class="nav-item">
         <a class="nav-link" href="donatchart2.php">
         <i class="fas fa-credit-card"></i>
             <span>Sales per SubKategori</span></a>
     </li>

               <!-- Nav Item - Edit Profile -->
    <li class="nav-item">
         <a class="nav-link" href="donatchart.php">
         <i class="fas fa-credit-card"></i>
             <span>Purchase per SubKategori</span></a>
     </li>


    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading User Profile-->
    <div class="sidebar-heading">
        OLAP
    </div>

    <!-- Nav Item - My Profile -->
    <li class="nav-item">
        <a class="nav-link" href="olap.php">
        <i class="fas fa-database"></i>
            <span>Mondrian</span></a>
    </li>
     <!-- Heading Data Customer-->

          <!-- Divider -->
          <hr class="sidebar-divider d-none d-md-block">

 
     <!-- Nav Item - Logout -->
     <li class="nav-item">
         <a class="nav-link" href="index.php">
             <i class="fas fa-sign-out-alt"></i>
             <span>Logout</span></a>
     </li>

     <!-- Divider -->
     <hr class="sidebar-divider d-none d-md-block">

     <!-- Sidebar Toggler (Sidebar) -->
     <div class="text-center d-none d-md-inline">
         <button class="rounded-circle border-0" id="sidebarToggle"></button>
     </div>


 </ul>
 <!-- End of Sidebar -->