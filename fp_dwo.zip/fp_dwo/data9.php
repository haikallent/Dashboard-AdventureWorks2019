<?php
require('connsales.php');

$sql1 = "SELECT f.ProductSubCategory kategori, 
        t.bulan as bulan,
       sum(fp.SalesAmount) as pendapatan 
    FROM dime_product f, factsales fp, dime_time t 
WHERE (f.ProductID = fp.ProductID) AND (t.TimeID = fp.TimeID) 
GROUP BY kategori, bulan";

$sql2 = "SELECT f.ProductSubCategory kategori, 
                sum(fp.SalesAmount) as pembagi 
                FROM dime_product f 
                JOIN factsales fp 
                ON (f.ProductID = fp.ProductID) 
                GROUP BY kategori";

$result1 = mysqli_query($conn,$sql1);
$result2 = mysqli_query($conn,$sql2);

$pendapatan = array();
$pembagi = array();

while ($row = mysqli_fetch_array($result1)) {
    array_push($pendapatan,array(
        "pendapatan"=>$row['pendapatan'],
        "bulan" => $row['bulan'],
        "kategori" => $row['kategori']
    ));
}

while ($row = mysqli_fetch_array($result2)) {
    array_push($pembagi,array(
        "kategori" => $row['kategori'],
        "pembagi"=>$row['pembagi']
    ));
}

$hasil = array();

function countPersen($nilai, $pembagi){
    return $nilai/$pembagi*100;
}

foreach ($pembagi as $item) {
    foreach ($pendapatan as $dapat) {
        if ($item["kategori"] == $dapat["kategori"]){
            array_push($hasil,array(
                "kategori" => $dapat['kategori'],
                "persen" => countPersen(floatval($dapat["pendapatan"]), floatval($item["pembagi"])),
                "bulan" => $dapat['bulan']
            ));
        }
    }
}

$data6 = json_encode($hasil);
?>
