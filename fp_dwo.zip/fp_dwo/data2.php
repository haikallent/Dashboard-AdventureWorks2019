<?php
require('connsales.php');

$sql1 = "SELECT s.TerritoryName kategori, 
        t.bulan as bulan,
       sum(fp.SalesAmount) as pendapatan 
    FROM dime_salesterritory s, factsales fp, dime_time t 
WHERE (s.TerritoryID = fp.TerritoryID) AND (t.TimeID = fp.TimeID) 
GROUP BY kategori, bulan";

$result1 = mysqli_query($conn,$sql1);

$pendapatan = array();

while ($row = mysqli_fetch_array($result1)) {
    array_push($pendapatan,array(
        "pendapatan"=>$row['pendapatan'],
        "bulan" => $row['bulan'],
        "kategori" => $row['kategori']
    ));
}

$data2 = json_encode($pendapatan);

?>