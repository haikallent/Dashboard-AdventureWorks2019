<?php
require('connsales.php');

$sql = "SELECT s.TerritoryName nama_toko, 
        SUM(p.SalesAmount) AS total
        FROM dime_salesterritory s, factsales p 
        WHERE s.TerritoryID = p.TerritoryID GROUP BY s.TerritoryName ORDER BY total DESC";
$result = mysqli_query($conn,$sql);

$hasil = array();

while ($row = mysqli_fetch_array($result)) {
    array_push($hasil,array(
        "name"=>$row['nama_toko'],
        "total"=>$row['total']
    ));
}

$data = json_encode($hasil);

?>