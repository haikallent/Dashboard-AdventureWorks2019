<?php
require('connpurchase.php');

$sql1 = "SELECT f.ProductCategory as kategori, 
t.Bulan as bulan,
SUM(fp.AmountPurchase) as lamapinjam 
FROM product f, fact_purchase fp, time t 
WHERE (f.ProductID = fp.ProductID) AND (t.TimeID = fp.TimeID) 
GROUP BY kategori, bulan";

$result1 = mysqli_query($conn,$sql1);

$lamapinjam = array();

while ($row = mysqli_fetch_array($result1)) {
    array_push($lamapinjam,array(
        "lamapinjam"=>$row['lamapinjam'],
        "bulan" => $row['bulan'],
        "kategori" => $row['kategori']
    ));
}
$data7 = json_encode($lamapinjam);

?>