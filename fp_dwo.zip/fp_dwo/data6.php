<?php
require('connpurchase.php');

$sql1 = "SELECT f.ProductSubCategory kategori, 
        t.bulan as bulan,
       sum(fp.AmountPurchase) as pendapatan 
    FROM product f, fact_purchase fp, time t 
WHERE (f.ProductID = fp.ProductID) AND (t.TimeID = fp.TimeID) 
GROUP BY kategori, bulan";

$sql2 = "SELECT f.ProductSubCategory kategori, 
                sum(fp.AmountPurchase) as pembagi 
                FROM product f 
                JOIN fact_purchase fp 
                ON (f.ProductID = fp.ProductID) 
                GROUP BY kategori";

$result1 = mysqli_query($conn,$sql1);
$result2 = mysqli_query($conn,$sql2);

$pendapatan = array();
$pembagi = array();

while ($row = mysqli_fetch_array($result1)) {
    array_push($pendapatan,array(
        "pendapatan"=>$row['pendapatan'],
        "bulan" => $row['bulan'],
        "kategori" => $row['kategori']
    ));
}

while ($row = mysqli_fetch_array($result2)) {
    array_push($pembagi,array(
        "kategori" => $row['kategori'],
        "pembagi"=>$row['pembagi']
    ));
}

$hasil = array();

function countPersen($nilai, $pembagi){
    return $nilai/$pembagi*100;
}

foreach ($pembagi as $item) {
    foreach ($pendapatan as $dapat) {
        if ($item["kategori"] == $dapat["kategori"]){
            array_push($hasil,array(
                "kategori" => $dapat['kategori'],
                "persen" => countPersen(floatval($dapat["pendapatan"]), floatval($item["pembagi"])),
                "bulan" => $dapat['bulan']
            ));
        }
    }
}

$data6 = json_encode($hasil);
?>
