<?php
require('connpurchase.php');

$sql = "SELECT f.ProductSubCategory as kategori, 
        SUM(p.AmountPurchase) AS total,
        (SUM(p.AmountPurchase) / (SELECT SUM(AmountPurchase) FROM fact_purchase)) * 100 AS 'persentase'
        FROM product f, fact_purchase p 
        WHERE f.ProductID = p.ProductID GROUP BY f.ProductSubCategory";
$result = mysqli_query($conn,$sql);

$hasil = array();

while ($row = mysqli_fetch_array($result)) {
    array_push($hasil,array(
        "name"=>$row['kategori'],
        "total"=>$row['total'],
        "y"=>$row['persentase']
    ));
}

$data5 = json_encode($hasil);
?>
