<?php
require('connsales.php');

$sql = "SELECT f.ProductSubCategory as kategori, 
        SUM(p.SalesAmount) AS total,
        (SUM(p.SalesAmount) / (SELECT SUM(SalesAmount) FROM factsales)) * 100 AS 'persentase'
        FROM dime_product f, factsales p 
        WHERE f.ProductID = p.ProductID GROUP BY f.ProductSubCategory";
$result = mysqli_query($conn,$sql);

$hasil = array();

while ($row = mysqli_fetch_array($result)) {
    array_push($hasil,array(
        "name"=>$row['kategori'],
        "total"=>$row['total'],
        "y"=>$row['persentase']
    ));
}

$data5 = json_encode($hasil);
?>
